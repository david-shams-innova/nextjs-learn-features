import React from 'react'

export default function card() {
  return (
    <div>card</div>
  )
}
